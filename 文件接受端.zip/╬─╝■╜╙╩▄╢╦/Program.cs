﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 文件接收端
{
    class Program
    {

        static int port = 3333;
        static BinaryWriter Bwfilw;
        static void Main(string[] args)
        {
            Bwfilw = new BinaryWriter(new FileStream("List.txt", FileMode.Append));
            IPAddress localIp;
            IPAddress[] ip = Dns.GetHostAddresses(Dns.GetHostName());
            localIp = ip[ip.Length - 1];// IPAddress.Parse(host);
            //Console.WriteLine("检测到本机可用IP：" + localIp.ToString());
            //Console.WriteLine("输入IP：");
            localIp = IPAddress.Parse("127.0.0.1");
            //localIp = IPAddress.Parse("172.21.16.51");
            //localIp = IPAddress.Parse(Console.ReadLine());
            IPEndPoint ipe = new IPEndPoint(localIp, port);
            Socket sSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            sSocket.Bind(ipe);
            sSocket.Listen(9999);



            while (true)
            {
                try
                {
                    Socket serverSocket = sSocket.Accept();
                    Console.WriteLine("连接已经建立");
                    Thread th = new Thread(new ParameterizedThreadStart(Re));
                    th.IsBackground = true;
                    th.Start(serverSocket);
                }
                catch (Exception e)
                {
                    Console.Write(e.ToString());
                }
            }
        }

        static void Re(Object s)
        {
            byte[] recByte = new byte[4096];
            byte[] sendByte = new byte[4096];
            Socket serverSocket = (Socket)s;
            BinaryWriter bw;
            DateTime d = DateTime.Now;
            int bytes;
            try
            {

                bytes = serverSocket.Receive(recByte, recByte.Length, 0);
                if (bytes == 2 && recByte[0] == 0xff && recByte[1] == 0xff)
                {
                    Bwfilw.Close();
                    Bwfilw = new BinaryWriter(new FileStream("List.txt", FileMode.Append));
                    return;
                }


                string FILE_NAME = d.ToString("MM-dd-HH-mm-ss-") + d.ToString("ffff") + ".doc";
                Bwfilw.Write(FILE_NAME + "   ---->   ");
                Bwfilw.Write(recByte, 0, bytes);
                Bwfilw.Write("\n");

                Console.WriteLine(FILE_NAME);
                bw = new BinaryWriter(new FileStream(FILE_NAME, FileMode.Create));
                serverSocket.Send(recByte, bytes, 0);
                bytes = serverSocket.Receive(recByte, recByte.Length, 0);
                serverSocket.Send(recByte, bytes, 0);
                do
                {
                    bytes = serverSocket.Receive(recByte, recByte.Length, 0);
                    bw.Write(recByte, 0, bytes);
                }
                while (bytes > 0);
                bw.Close();
                serverSocket.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }



    }
}
