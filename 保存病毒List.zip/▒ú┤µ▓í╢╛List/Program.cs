﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace 保存病毒List
{
    class Program
    {
        static int port = 3333;
        static void Main(string[] args)
        {
            IPAddress ip = IPAddress.Parse("39.105.49.161");
            IPEndPoint ipe = new IPEndPoint(ip, port);
            Socket socker = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socker.Connect(ipe);
            byte[] sendByte = new byte[2];
            sendByte[0] = 0xff;
            sendByte[1] = 0xff;
            socker.Send(sendByte);
             socker.Close();
            
        }
    }
}
